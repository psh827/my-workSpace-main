package com.varxyz.banking.domain;

public class SavingAccount extends Account{
	
	private double interestRate;
	
	public double getInterestRate() {
		return interestRate;
	}
	
	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}
	
	public void withdraw(double amount) {
		try {
			if(balance - amount < 0) {
				//예외발생
				throw new LackOfBalanceException("잔고부족");
			}			
		} catch (LackOfBalanceException e) {
			System.out.println(e.getMessage());
		}
		super.balance -= amount;
	}
}
